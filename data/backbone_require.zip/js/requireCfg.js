﻿'use strict';

define(function () {
    return {
        // The shim config allows us to configure dependencies for
        // scripts that do not call define() to register a module
        shim: {
            underscore: {
                exports: '_'
            },
            json2: {
                exports: 'JSON'
            },
            backbone: {
                deps: [
                    'underscore',
                    'jquery'
                ],
                exports: 'Backbone'
            },
            backboneLocalstorage: {
                deps: ['backbone'],
                exports: 'Store'
            }
        },
        paths: {
            jquery: '/components/jquery/jquery',
            underscore: '/components/underscore/underscore',
            json2: '/components/json2/json2',
            backbone: '/components/backbone/backbone',
            backboneLocalstorage: '/components/backbone.localStorage/backbone.localStorage',
            text: '/components/requirejs-text/text'
        }
    };
});

