'use strict';

require(['/js/requireCfg.js', 'entry'], function (Cfg, Entry) {
    if (typeof Entry.baseUrl === 'string') Cfg.baseUrl = Entry.baseUrl;
    // Require.js allows us to configure shortcut alias
    require.config(Cfg);
    Entry.init();
});

define('entry', function () {
    return {        
        // If no baseUrl is explicitly set in the configuration, 
        // the default value will be the location of the HTML page that loads require.js. 
        // If a data-main attribute is used, that path will become the baseUrl
        // baseUrl: 'js/sample-page',

        init: function () {

            // code here
            require([
                'backbone',
                'views/app',
                'routers/router'
            ], function (Backbone, AppView, Workspace) {
                /*jshint nonew:false*/
                // Initialize routing and start Backbone.history()
                new Workspace();
                Backbone.history.start();

                // Initialize the application view
                new AppView();
            });
        }
    };

});