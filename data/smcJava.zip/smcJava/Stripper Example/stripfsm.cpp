//----------------------------------------------
// stripfsm.cpp
// FSM:       StripFSM
// Context:   StripperContext
// Version:   Test version 1.0
// Generated: Tuesday 06/09/1998 at 19:44:16 CDT
//
//----------------------------------------------


static char _versID[]  = "Test version 1.0";

#include "stripfsm.h"

namespace smc
{

//----------------------------------------------
// Definitions of static state objects
//----------------------------------------------
StripFSMstarAfterSlashState StripFSM::starAfterSlash;
StripFSMstartingStarState StripFSM::startingStar;
StripFSMstartingSlashState StripFSM::startingSlash;
StripFSMsecondSlashState StripFSM::secondSlash;
StripFSMoutsideState StripFSM::outside;

//----------------------------------------------
// Default Event Functions
//----------------------------------------------

void StripFSMState::EOL(StripFSM& s)
  { s.FSMError("EOL", s.GetState().StateName()); }

void StripFSMState::Star(StripFSM& s)
  { s.FSMError("Star", s.GetState().StateName()); }

void StripFSMState::Slash(StripFSM& s)
  { s.FSMError("Slash", s.GetState().StateName()); }

void StripFSMState::Other(StripFSM& s)
  { s.FSMError("Other", s.GetState().StateName()); }

//----------------------------------------------
// The States and their Transitions
//----------------------------------------------

//----------------------------------------------
// starAfterSlash Actions and Transitions
//----------------------------------------------

// Starting State: starAfterSlash
// Event:          Star
//
void StripFSMstarAfterSlashState::Star( StripFSM& s )
{
    // Change the state
    s.SetState(StripFSM::startingStar);

    // Exit functions for: starAfterSlash
    s.StarAfterSlashOut();

    // Entry functions for: startingStar
    s.StartingStarIn();
}

// Starting State: starAfterSlash
// Event:          Slash
//
void StripFSMstarAfterSlashState::Slash( StripFSM& s )
{}

// Starting State: starAfterSlash
// Event:          Other
//
void StripFSMstarAfterSlashState::Other( StripFSM& s )
{}

// Starting State: starAfterSlash
// Event:          EOL
//
void StripFSMstarAfterSlashState::EOL( StripFSM& s )
{}

//----------------------------------------------
// startingStar Actions and Transitions
//----------------------------------------------

// Starting State: startingStar
// Event:          Slash
//
void StripFSMstartingStarState::Slash( StripFSM& s )
{
    // Change the state
    s.SetState(StripFSM::outside);

    // Exit functions for: startingStar
    s.StartingStarOut();

    // Exit functions for: inComment
    s.InCommentOut();

    // Entry functions for: outside
    s.OutsideIn();
}

// Starting State: startingStar
// Event:          EOL
//
void StripFSMstartingStarState::EOL( StripFSM& s )
{
    // Change the state
    s.SetState(StripFSM::starAfterSlash);

    // Exit functions for: startingStar
    s.StartingStarOut();

    // Entry functions for: starAfterSlash
    s.StarAfterSlashIn();
}

// Starting State: startingStar
// Event:          Other
//
void StripFSMstartingStarState::Other( StripFSM& s )
{
    // Change the state
    s.SetState(StripFSM::starAfterSlash);

    // Exit functions for: startingStar
    s.StartingStarOut();

    // Entry functions for: starAfterSlash
    s.StarAfterSlashIn();
}

// Starting State: startingStar
// Event:          Star
//
void StripFSMstartingStarState::Star( StripFSM& s )
{}

//----------------------------------------------
// startingSlash Actions and Transitions
//----------------------------------------------

// Starting State: startingSlash
// Event:          Slash
//
void StripFSMstartingSlashState::Slash( StripFSM& s )
{
    // Change the state
    s.SetState(StripFSM::secondSlash);

    // Exit functions for: startingSlash
    s.StartingSlashOut();

    // Entry functions for: inComment
    s.InCommentIn();

    // Entry functions for: secondSlash
    s.SecondSlashIn();
}

// Starting State: startingSlash
// Event:          Star
//
void StripFSMstartingSlashState::Star( StripFSM& s )
{
    // Change the state
    s.SetState(StripFSM::starAfterSlash);

    // Exit functions for: startingSlash
    s.StartingSlashOut();

    // Entry functions for: inComment
    s.InCommentIn();

    // Entry functions for: starAfterSlash
    s.StarAfterSlashIn();
}

// Starting State: startingSlash
// Event:          EOL
//
void StripFSMstartingSlashState::EOL( StripFSM& s )
{
    s.PutSlash();
    s.PutChar();

    // Change the state
    s.SetState(StripFSM::outside);

    // Exit functions for: startingSlash
    s.StartingSlashOut();

    // Entry functions for: outside
    s.OutsideIn();
}

// Starting State: startingSlash
// Event:          Other
//
void StripFSMstartingSlashState::Other( StripFSM& s )
{
    s.PutSlash();
    s.PutChar();

    // Change the state
    s.SetState(StripFSM::outside);

    // Exit functions for: startingSlash
    s.StartingSlashOut();

    // Entry functions for: outside
    s.OutsideIn();
}

//----------------------------------------------
// secondSlash Actions and Transitions
//----------------------------------------------

// Starting State: secondSlash
// Event:          EOL
//
void StripFSMsecondSlashState::EOL( StripFSM& s )
{
    s.PutChar();

    // Change the state
    s.SetState(StripFSM::outside);

    // Exit functions for: secondSlash
    s.SecondSlashOut();

    // Exit functions for: inComment
    s.InCommentOut();

    // Entry functions for: outside
    s.OutsideIn();
}

// Starting State: secondSlash
// Event:          Slash
//
void StripFSMsecondSlashState::Slash( StripFSM& s )
{}

// Starting State: secondSlash
// Event:          Other
//
void StripFSMsecondSlashState::Other( StripFSM& s )
{}

// Starting State: secondSlash
// Event:          Star
//
void StripFSMsecondSlashState::Star( StripFSM& s )
{}

//----------------------------------------------
// outside Actions and Transitions
//----------------------------------------------

// Starting State: outside
// Event:          EOL
//
void StripFSMoutsideState::EOL( StripFSM& s )
{
    s.PutChar();
}

// Starting State: outside
// Event:          Other
//
void StripFSMoutsideState::Other( StripFSM& s )
{
    s.PutChar();
}

// Starting State: outside
// Event:          Slash
//
void StripFSMoutsideState::Slash( StripFSM& s )
{
    // Change the state
    s.SetState(StripFSM::startingSlash);

    // Exit functions for: outside
    s.OutsideOut();

    // Entry functions for: startingSlash
    s.StartingSlashIn();
}

// Starting State: outside
// Event:          Star
//
void StripFSMoutsideState::Star( StripFSM& s )
{
    s.PutChar();
}

//----------------------------------------------
// State Machine Constructor: StripFSM
//  set Initial State to: outside
//
//----------------------------------------------
StripFSM::StripFSM() 
: itsState(&outside)
{
    // Entry functions for: outside
    OutsideIn();
}

//  Get version information
//
const char* StripFSM::GetVersion() const
{ return _versID; }

}  // end namespace smc

