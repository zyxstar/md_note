#ifndef FSM_StripFSM_06_09_1998_19_44_16_H
#define FSM_StripFSM_06_09_1998_19_44_16_H
//----------------------------------------------
// stripfsm.h
// FSM:       StripFSM
// Context:   StripperContext
// Version:   Test version 1.0
// Generated: Tuesday 06/09/1998 at 19:44:16 CDT
//
//----------------------------------------------


// Included header files

#include "stContext.h"
#include <stddef.h>

namespace smc
{

// Forward Declarations

class StripFSM;

//----------------------------------------------
// StripFSMState: The base state class
//----------------------------------------------
class StripFSMState
{
  public: 
    virtual const char* StateName() const = 0;
    virtual void EOL( StripFSM& );
    virtual void Star( StripFSM& );
    virtual void Slash( StripFSM& );
    virtual void Other( StripFSM& );
};

//----------------------------------------------
// State: starAfterSlash
//----------------------------------------------
class StripFSMstarAfterSlashState : public StripFSMState
{
  public: 
    virtual const char* StateName() const
        { return "starAfterSlash"; }
    virtual void Star( StripFSM& );
    virtual void Slash( StripFSM& );
    virtual void Other( StripFSM& );
    virtual void EOL( StripFSM& );
};

//----------------------------------------------
// State: startingStar
//----------------------------------------------
class StripFSMstartingStarState : public StripFSMState
{
  public: 
    virtual const char* StateName() const
        { return "startingStar"; }
    virtual void Slash( StripFSM& );
    virtual void EOL( StripFSM& );
    virtual void Other( StripFSM& );
    virtual void Star( StripFSM& );
};

//----------------------------------------------
// State: startingSlash
//----------------------------------------------
class StripFSMstartingSlashState : public StripFSMState
{
  public: 
    virtual const char* StateName() const
        { return "startingSlash"; }
    virtual void Slash( StripFSM& );
    virtual void Star( StripFSM& );
    virtual void EOL( StripFSM& );
    virtual void Other( StripFSM& );
};

//----------------------------------------------
// State: secondSlash
//----------------------------------------------
class StripFSMsecondSlashState : public StripFSMState
{
  public: 
    virtual const char* StateName() const
        { return "secondSlash"; }
    virtual void EOL( StripFSM& );
    virtual void Slash( StripFSM& );
    virtual void Other( StripFSM& );
    virtual void Star( StripFSM& );
};

//----------------------------------------------
// State: outside
//----------------------------------------------
class StripFSMoutsideState : public StripFSMState
{
  public: 
    virtual const char* StateName() const
        { return "outside"; }
    virtual void EOL( StripFSM& );
    virtual void Other( StripFSM& );
    virtual void Slash( StripFSM& );
    virtual void Star( StripFSM& );
};

//----------------------------------------------
// StripFSM: The Finite State Machine class
//----------------------------------------------
class StripFSM: public StripperContext
{
  public: 
    // Static State variables
    static StripFSMstarAfterSlashState starAfterSlash;
    static StripFSMstartingStarState startingStar;
    static StripFSMstartingSlashState startingSlash;
    static StripFSMsecondSlashState secondSlash;
    static StripFSMoutsideState outside;

    StripFSM(); // default Constructor

    // Event functions
    void EOL() { itsState->EOL( *this ); }
    void Star() { itsState->Star( *this ); }
    void Slash() { itsState->Slash( *this ); }
    void Other() { itsState->Other( *this ); }

    // State Accessor functions
    void SetState( StripFSMState& theState ) { itsState = &theState; }
    StripFSMState& GetState() const { return *itsState; }

    const char* GetCurrentStateName() const { return itsState->StateName(); }
    const char* GetVersion() const;

  private:
    StripFSMState* itsState;
};

}  // end namespace smc

#endif /* FSM_StripFSM_06_09_1998_19_44_16_H */
