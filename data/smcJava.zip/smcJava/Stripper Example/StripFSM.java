package smc.stripper;
//----------------------------------------------
//
// FSM:       StripFSM
// Context:   StripperContext
// Err Func:  FSMError
// Version:   Test version 1.0
// Generated: Thursday 06/11/1998 at 15:47:42 CDT
//
//----------------------------------------------


// imports
import smc.stripper.StripperContext;
import smc.stripper.FSMException;

//----------------------------------------------
//
// class StripFSM
//    This is the Finite State Machine class
//
public class StripFSM extends StripperContext
{
  private State itsState;
  private static String itsVersion = "Test version 1.0";

  // instance variables for each state
  private static StarAfterSlash itsStarAfterSlashState;
  private static StartingStar itsStartingStarState;
  private static StartingSlash itsStartingSlashState;
  private static SecondSlash itsSecondSlashState;
  private static Outside itsOutsideState;

  // constructor
  public StripFSM()
  {
    itsStarAfterSlashState = new StarAfterSlash();
    itsStartingStarState = new StartingStar();
    itsStartingSlashState = new StartingSlash();
    itsSecondSlashState = new SecondSlash();
    itsOutsideState = new Outside();

    itsState = itsOutsideState;

    // Entry functions for: outside
    OutsideIn();
  }

  // accessor functions

  public String getVersion()
  {
    return itsVersion;
  }

  public String getCurrentStateName()
  {
    return itsState.stateName();
  }

  // event functions - forward to the current State

  public void EOL()
  {
    itsState.eOL();
  }

  public void Star()
  {
    itsState.star();
  }

  public void Slash()
  {
    itsState.slash();
  }

  public void Other()
  {
    itsState.other();
  }

  //--------------------------------------------
  //
  // private class State
  //    This is the base State class
  //
  private abstract class State
  {
    public abstract String stateName();

    // default event functions

    public void eOL()
    {
      FSMError( "EOL", itsState.stateName());
    }

    public void star()
    {
      FSMError( "Star", itsState.stateName());
    }

    public void slash()
    {
      FSMError( "Slash", itsState.stateName());
    }

    public void other()
    {
      FSMError( "Other", itsState.stateName());
    }

  }

  //--------------------------------------------
  //
  // class StarAfterSlash
  //    handles the starAfterSlash State and its events
  //
  private class StarAfterSlash extends State 
  {
    public String stateName() 
      { return "starAfterSlash"; }

    //
    // responds to Star event
    //
    public void star() 
    {
      // change the state
      itsState = itsStartingStarState;

      // Exit functions for: starAfterSlash
      StarAfterSlashOut();

      // Entry functions for: startingStar
      StartingStarIn();
    }

    //
    // responds to Slash event
    //
    public void slash() 
    {}

    //
    // responds to Other event
    //
    public void other() 
    {}

    //
    // responds to EOL event
    //
    public void eOL() 
    {}
  }

  //--------------------------------------------
  //
  // class StartingStar
  //    handles the startingStar State and its events
  //
  private class StartingStar extends State 
  {
    public String stateName() 
      { return "startingStar"; }

    //
    // responds to Slash event
    //
    public void slash() 
    {
      // change the state
      itsState = itsOutsideState;

      // Exit functions for: startingStar
      StartingStarOut();

      // Exit functions for: inComment
      InCommentOut();

      // Entry functions for: outside
      OutsideIn();
    }

    //
    // responds to EOL event
    //
    public void eOL() 
    {
      // change the state
      itsState = itsStarAfterSlashState;

      // Exit functions for: startingStar
      StartingStarOut();

      // Entry functions for: starAfterSlash
      StarAfterSlashIn();
    }

    //
    // responds to Other event
    //
    public void other() 
    {
      // change the state
      itsState = itsStarAfterSlashState;

      // Exit functions for: startingStar
      StartingStarOut();

      // Entry functions for: starAfterSlash
      StarAfterSlashIn();
    }

    //
    // responds to Star event
    //
    public void star() 
    {}
  }

  //--------------------------------------------
  //
  // class StartingSlash
  //    handles the startingSlash State and its events
  //
  private class StartingSlash extends State 
  {
    public String stateName() 
      { return "startingSlash"; }

    //
    // responds to Slash event
    //
    public void slash() 
    {
      // change the state
      itsState = itsSecondSlashState;

      // Exit functions for: startingSlash
      StartingSlashOut();

      // Entry functions for: inComment
      InCommentIn();

      // Entry functions for: secondSlash
      SecondSlashIn();
    }

    //
    // responds to Star event
    //
    public void star() 
    {
      // change the state
      itsState = itsStarAfterSlashState;

      // Exit functions for: startingSlash
      StartingSlashOut();

      // Entry functions for: inComment
      InCommentIn();

      // Entry functions for: starAfterSlash
      StarAfterSlashIn();
    }

    //
    // responds to EOL event
    //
    public void eOL() 
    {
      PutSlash();
      PutChar();

      // change the state
      itsState = itsOutsideState;

      // Exit functions for: startingSlash
      StartingSlashOut();

      // Entry functions for: outside
      OutsideIn();
    }

    //
    // responds to Other event
    //
    public void other() 
    {
      PutSlash();
      PutChar();

      // change the state
      itsState = itsOutsideState;

      // Exit functions for: startingSlash
      StartingSlashOut();

      // Entry functions for: outside
      OutsideIn();
    }
  }

  //--------------------------------------------
  //
  // class SecondSlash
  //    handles the secondSlash State and its events
  //
  private class SecondSlash extends State 
  {
    public String stateName() 
      { return "secondSlash"; }

    //
    // responds to EOL event
    //
    public void eOL() 
    {
      PutChar();

      // change the state
      itsState = itsOutsideState;

      // Exit functions for: secondSlash
      SecondSlashOut();

      // Exit functions for: inComment
      InCommentOut();

      // Entry functions for: outside
      OutsideIn();
    }

    //
    // responds to Star event
    //
    public void star() 
    {}

    //
    // responds to Slash event
    //
    public void slash() 
    {}

    //
    // responds to Other event
    //
    public void other() 
    {}
  }

  //--------------------------------------------
  //
  // class Outside
  //    handles the outside State and its events
  //
  private class Outside extends State 
  {
    public String stateName() 
      { return "outside"; }

    //
    // responds to Star event
    //
    public void star() 
    {
      PutChar();
    }

    //
    // responds to EOL event
    //
    public void eOL() 
    {
      PutChar();
    }

    //
    // responds to Other event
    //
    public void other() 
    {
      PutChar();
    }

    //
    // responds to Slash event
    //
    public void slash() 
    {
      // change the state
      itsState = itsStartingSlashState;

      // Exit functions for: outside
      OutsideOut();

      // Entry functions for: startingSlash
      StartingSlashIn();
    }
  }

}
