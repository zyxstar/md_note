VERSION
  27-Oct-2006

Fixed but in C++ generator that did not emit event methods for superclasses.  Also made event function in main FSM class virtual. -- UB

