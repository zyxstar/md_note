
// #define FILTER_ELEM int


typedef struct{
  int name;
  int score;
} TAG;

#define FILTER_ELEM TAG


// 是否可在引用filter.h的c文件（main函数的文件中）中定义类型，而不是在此处
// 不同的main文件中，可以根据自己的需要来定义类型，达到该函数的通用性
