﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace MVCDemo
{
    public interface IController
    {
        void SetScore(int score);      
        void AddView(IView view);
    }

    public class Controller : IController
    {
        private List<IView> views;//一个model可能会有多个view
        private IModel model;
        /// <summary>
        /// controller与view同样是model的观察者
        /// </summary>
        /// <param name="model"></param>
        public Controller(IModel model)
        {
            this.model = model;
            views = new List<IView>();
        }

        public void AddView(IView view)
        {
            views.Add(view);
            view.SetEntironment(this, model);

            Form form = view as Form;//如果view是窗体话，让它运行起来,如果为了扩展好，这里应该设计成多态
            if (form != null)
            {
                ThreadPool.QueueUserWorkItem(new WaitCallback(delegate{Application.Run(form);}));                
            }
        }
      
        public void SetScore(int score)
        {
            model.Score = score;
        }      
    }
}
