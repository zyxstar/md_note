﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MVCDemo
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            //这里将所有接口赋上实现类
            IModel model = new Model();
            IController controller = new Controller(model);
            controller.AddView(new MainForm());
            //再加一个view
            controller.AddView(new MainForm());

            //以下窗口仅为了关闭此程序使用(主线程在此),如果是控制台程序则使用Console.Read();
            Application.Run(new Form());            
        }
    }
}