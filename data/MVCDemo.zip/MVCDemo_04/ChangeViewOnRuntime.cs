﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MVCDemo
{
    public partial class ChangeViewOnRuntime : Form
    {
        IModel model;
        IController controller;

        public ChangeViewOnRuntime()
        {
            InitializeComponent();

            //这里将所有接口赋上实现类
            model = new Model();
            controller = new Controller(model);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int count = (int)numericUpDown1.Value;
            AddView<MainForm>(count);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int count = (int)numericUpDown2.Value;
            AddView<OnlyControl>(count);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int count = (int)numericUpDown3.Value;
            AddView<OnlyView>(count);
        }

        void AddView<T>(int count) where T : IView, new()
        {
            for (int i = 0; i < count; i++)
            {
                controller.AddView(new T());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show(controller.ViewCount.ToString());
        }

    }
}