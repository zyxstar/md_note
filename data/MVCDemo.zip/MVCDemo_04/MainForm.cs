using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MVCDemo
{
    public partial class MainForm : Form, IView//�ô��ڳ���IView��ʵ���࣬��Ҫ��ϸ���ȵĿؼ���Ϊview
    {
        private IController controller;
        private IModel model;
        delegate void SetScoreCallback(int Score);

        public MainForm()
        {
            InitializeComponent();
        }

        public void SetEntironment(IController controller, IModel model)
        {
            this.model = model;
            this.controller = controller;

            //�趨model�Ĺ۲���
            model.ScoreChangeHandler += new EventHandler(model_ScoreChangeHandler);
            //����Ŀؼ�����ԭ���ؼ������Ǽ̳��˽ӿڵĿؼ�
            this.btnGoBack.Click += new EventHandler(btnGoBack_Click);
            this.btnGohead.Click += new EventHandler(btnGohead_Click);
            this.scoreTrackBar1.Scroll += new EventHandler(scoreTrackBar1_Scroll);
            model_ScoreChangeHandler(this.model, null);
        }

        void scoreTrackBar1_Scroll(object sender, EventArgs e)
        {
            controller.SetScore(this.scoreTrackBar1.Value);
        }

        void model_ScoreChangeHandler(object sender, EventArgs e)
        {
            //model�����״̬��ӳ��view������,���ڸ���UI��ó����UI��״̬��Ȼ��ֱ���޸����״̬����
            IModel model = (IModel)sender;

            //Control.CheckForIllegalCrossThreadCalls = false;//���̴߳���֪ͨ�����ʹ��delegate��ʽ          
            SetScore(model.Score);
           
        }

        void SetScore(int Score)
        {
            if (this.InvokeRequired)
            {
                SetScoreCallback d = new SetScoreCallback(SetScore);
                this.Invoke(d, new object[] { Score });
            }
            else
            {
                this.scoreProgressBar1.Value = Score;
                this.scoreTrackBar1.Value = Score;
            }
        }

        void btnGohead_Click(object sender, EventArgs e)
        {
            //����û���߼�����֤��ֻ�ǵ���controller�ķ���
            controller.SetScore(this.scoreProgressBar1.Value + 1);
        }

        void btnGoBack_Click(object sender, EventArgs e)
        {
            controller.SetScore(this.scoreProgressBar1.Value - 1);
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            controller.RemoveView(this);
        }        
    }
}