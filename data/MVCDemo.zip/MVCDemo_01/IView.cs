﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MVCDemo
{
    public interface IView
    {
        void SetEntironment(IController controller, IModel model);
    }
}
