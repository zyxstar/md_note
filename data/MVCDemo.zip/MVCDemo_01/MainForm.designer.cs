﻿using System.Windows.Forms;
namespace MVCDemo
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGohead = new System.Windows.Forms.Button();
            this.btnGoBack = new System.Windows.Forms.Button();
            this.scoreTrackBar1 = new TrackBar();
            this.scoreProgressBar1 = new ProgressBar();
            ((System.ComponentModel.ISupportInitialize)(this.scoreTrackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGohead
            // 
            this.btnGohead.Location = new System.Drawing.Point(492, 39);
            this.btnGohead.Name = "btnGohead";
            this.btnGohead.Size = new System.Drawing.Size(25, 23);
            this.btnGohead.TabIndex = 2;
            this.btnGohead.Text = "+";
            this.btnGohead.UseVisualStyleBackColor = true;
            // 
            // btnGoBack
            // 
            this.btnGoBack.Location = new System.Drawing.Point(43, 39);
            this.btnGoBack.Name = "btnGoBack";
            this.btnGoBack.Size = new System.Drawing.Size(25, 23);
            this.btnGoBack.TabIndex = 3;
            this.btnGoBack.Text = "-";
            this.btnGoBack.UseVisualStyleBackColor = true;
            // 
            // scoreTrackBar1
            // 
            this.scoreTrackBar1.Location = new System.Drawing.Point(43, 68);
            this.scoreTrackBar1.Maximum = 100;
            this.scoreTrackBar1.Name = "scoreTrackBar1";
            this.scoreTrackBar1.Size = new System.Drawing.Size(474, 45);
            this.scoreTrackBar1.TabIndex = 1;
            this.scoreTrackBar1.TickFrequency = 10;
            // 
            // scoreProgressBar1
            // 
            this.scoreProgressBar1.Location = new System.Drawing.Point(76, 39);
            this.scoreProgressBar1.Name = "scoreProgressBar1";
            this.scoreProgressBar1.Size = new System.Drawing.Size(410, 23);
            this.scoreProgressBar1.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 149);
            this.Controls.Add(this.btnGoBack);
            this.Controls.Add(this.btnGohead);
            this.Controls.Add(this.scoreTrackBar1);
            this.Controls.Add(this.scoreProgressBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.Text = "MVC Demo";
            ((System.ComponentModel.ISupportInitialize)(this.scoreTrackBar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ProgressBar scoreProgressBar1;
        private TrackBar scoreTrackBar1;
        private System.Windows.Forms.Button btnGohead;
        private System.Windows.Forms.Button btnGoBack;

    }
}

