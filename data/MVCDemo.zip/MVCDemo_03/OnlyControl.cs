﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MVCDemo
{
    public partial class OnlyControl : Form, IView
    {
        public OnlyControl()
        {
            InitializeComponent();
        }

        private IController controller;

        public void SetEntironment(IController controller, IModel model)
        {
            //由于只当controller，所以没必要使用model
            this.controller = controller;
            this.btnClick.Click += new EventHandler(btnClick_Click);
        }

        void btnClick_Click(object sender, EventArgs e)
        {
            int score = 0;
            if(int.TryParse(this.txScore.Text, out score))         
                controller.SetScore(score);
        }
    }
}