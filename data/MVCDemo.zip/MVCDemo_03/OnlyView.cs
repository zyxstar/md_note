﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MVCDemo
{
    public partial class OnlyView : Form, IView
    {
        public OnlyView()
        {
            InitializeComponent();
        }

        private IModel model;
        private IController controller;//为了统一控制所加，其实可以不加，使用单独的观察机制

        public void SetEntironment(IController controller, IModel model)
        {
            this.model = model;
            this.controller = controller;

            this.model.ScoreChangeHandler += new EventHandler(model_ScoreChangeHandler);
        }

        void model_ScoreChangeHandler(object sender, EventArgs e)
        {
            IModel model = (IModel)sender;

            Control.CheckForIllegalCrossThreadCalls = false;
            this.label1.Text = model.Score.ToString();
        }
    }
}